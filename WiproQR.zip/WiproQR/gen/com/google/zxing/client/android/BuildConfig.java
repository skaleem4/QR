/** Automatically generated file. DO NOT MODIFY */
package com.google.zxing.client.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}